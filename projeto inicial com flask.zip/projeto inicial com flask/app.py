from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)


class Dados_Cadastrais(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cpf = db.Column(db.String(11), nullable=False)
    nome = db.Column(db.String(255), nullable=False)
    rua = db.Column(db.String(255), nullable=False)
    cidade = db.Column(db.String(255), nullable=False)
    estado = db.Column(db.String(255), nullable=False)


@app.route("/home")
def home():
    return render_template("index.html")


@app.route("/cadastrar", methods=["POST"])
def cadastrar():

    cpf = request.form["cpf"]
    nome = request.form["nome"]
    rua = request.form["rua"]
    cidade = request.form["cidade"]
    estado = request.form["estado"]

    if not cpf or not nome or not rua or not cidade or not estado:
        return "Erro: Todos os campos precisam ser preenchidos!"

    novo_cliente = Dados_Cadastrais(
        cpf=cpf,
        nome=nome,
        rua=rua,
        cidade=cidade,
        estado=estado
    )

    db.session.add(novo_cliente)
    db.session.commit()

    return f"Cliente {nome} cadastrado com sucesso!"


@app.route("/admin")
def admin():

    clientes = Dados_Cadastrais.query.all()

    return render_template("admin.html", clientes=clientes)


if __name__ == "__main__":
    with app.app_context():
        db.create_all()

    app.run(debug=True)